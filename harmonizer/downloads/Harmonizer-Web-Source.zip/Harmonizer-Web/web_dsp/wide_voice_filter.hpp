#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

// Large upward shifts sometimes leave source-period sidebands in a held vowel.
// Below its target fundamental a voiced note has no harmonic partials. Above it,
// averaging copies one target period apart reinforces the original harmonic
// envelope without replacing it with oscillators. No lookahead or queued block.
class WideVoiceFilter {
public:
    explicit WideVoiceFilter(int rate) : rate_(rate) {
        int size = 1;
        while (size < 6 * rate / 120 + 8) size *= 2;
        delay_.assign(size, 0.0f);
        mask_ = size-1;
        slew_ = 1.0f - std::exp(-1.0f / (0.002f * rate));
    }

    void reset() {
        filled_ = 0;
        mix_ = 0;
        stages_ = {};
        note_ = -1;
    }

    void process(float* samples, int n, float target, float shift, bool voiced) {
        float wanted = voiced ? std::clamp((shift-20.0f)/7.0f, 0.0f, 1.0f) : 0.0f;
        if (!wanted && mix_ < 0.0001f) {
            if (filled_) reset();
            return;
        }
        if (target != note_) {
            const float freq=440.0f*std::exp2((target-69.0f)/12.0f);
            if (freq < 120 || freq > rate_*.45f) { reset(); return; }
            if (std::fabs(target-note_) >= .5f) reset();
            note_ = target;
            const float period=rate_/freq;
            for(int j=0;j<6;j++) {
                const float d=period*(j+1);
                offset_[j]=int(d); fraction_[j]=d-offset_[j];
            }
            const float k=std::tan(3.14159265359f*.78f*freq/rate_);
            for(int i=0;i<2;i++) {
                const float a = k/(i ? 1.306563f : .541196f), norm=1/(1+a+k*k);
                stages_[i].b=norm; stages_[i].a1=2*(k*k-1)*norm; stages_[i].a2=(1-a+k*k)*norm;
            }
        }
        for (int i=0;i<n;i++) {
            float x=samples[i];
            for (auto& s:stages_) {
                const float y=s.b*x+s.z1;
                s.z1=s.z2-2*s.b*x-s.a1*y; s.z2=s.b*x-s.a2*y; x=y;
            }
            delay_[write_]=x;
            float sum=x;
            // Two four-period means in series, expanded into seven triangular taps.
            constexpr int weight[]={2,3,4,3,2,1};
            for(int j=0;j<6;j++) {
                const int i0=(write_ - offset_[j]) & mask_;
                sum+=weight[j]*(delay_[i0]+fraction_[j]*(delay_[(i0-1)&mask_]-delay_[i0]));
            }
            write_=(write_+1)&mask_;
            if(filled_<=offset_[5]+1) { ++filled_; continue; }
            mix_+=slew_*(wanted-mix_);
            samples[i]+=mix_*((1.0f/16.0f)*sum-samples[i]);
        }
    }
private:
    struct Stage { float b{}, a1{}, a2{}, z1{}, z2{}; };
    int rate_, mask_{}, write_{}, filled_{};
    float slew_{}, mix_{}, note_{-1};
    std::array<Stage,2> stages_{};
    std::array<int,6> offset_{};
    std::array<float,6> fraction_{};
    std::vector<float> delay_;
};
