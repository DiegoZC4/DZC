#!/usr/bin/env node

import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const scriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(scriptDirectory, "..");
const builtPath = path.join(root, "dist", "Harmonizer-Web-Offline.html");
const html = await readFile(builtPath, "utf8");

assert.match(html, /^<!doctype html>/i);
assert.match(html, /id="harmonizer-standalone-payloads"/);
assert.match(html, /id="harmonizer-licenses"/);
for (const license of ["LICENSE", "public/vendor/LICENSE-rubberband.txt", "public/vendor/LICENSE-signalsmith-stretch.txt"]) {
  assert.ok(html.includes(await readFile(path.join(root, license), "utf8")), license);
}
assert.ok(html.includes('href="https://diegozc.com/harmonizer/downloads/Harmonizer-Web-Source.zip"'));
assert.match(html, /href="\.\/Harmonizer-Web-Offline\.html"/);
assert.match(html, /href="data:image\/svg\+xml;base64,/);
assert.doesNotMatch(html, /<script[^>]+src=/i);
assert.doesNotMatch(html, /\.\/(?:app|pitch-worklet|rubberband-worklet)\.js/);
assert.ok(Buffer.byteLength(html) > 500_000, "standalone output is unexpectedly small");
assert.ok(Buffer.byteLength(html) < 1_500_000, "standalone output is unexpectedly large");

const payloadMatch = html.match(
  /<script id="harmonizer-standalone-payloads" type="application\/json">([^<]+)<\/script>/,
);
assert.ok(payloadMatch, "standalone payload JSON is missing");
const payloads = JSON.parse(payloadMatch[1]);
const decode = (encoded) => Buffer.from(encoded, "base64").toString("utf8");
const app = decode(payloads.app);
const pitchWorklet = decode(payloads.pitchWorklet);
const rubberBandWorklet = decode(payloads.rubberBandWorklet);
const signalsmith = decode(payloads.signalsmith);

assert.match(html, /"data:text\/javascript;base64," \+ encoded/);
assert.doesNotMatch(html, /URL\.createObjectURL/);
assert.match(app, /SignalsmithStretch\.moduleUrl = embeddedWorkletUrls\.signalsmith/);
assert.equal(signalsmith, await readFile(path.join(root, "public", "vendor", "SignalsmithStretch.js"), "utf8"));
assert.match(app, /SignalsmithStretch/);
assert.match(app, /RealtimePitchTracker/);
assert.match(app, /buildRubberBandEngine/);
assert.match(pitchWorklet, /registerProcessor\("harmonizer-pitch-control"/);
assert.match(rubberBandWorklet, /createRubberBandLiveModule/);
assert.match(rubberBandWorklet, /registerProcessor\("rubberband-harmonizer"/);
for (const source of [app, pitchWorklet, rubberBandWorklet]) {
  assert.doesNotMatch(source, /(^|\n)\s*(import|export)\s/m);
}

const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), "harmonizer-single-file-"));
try {
  for (const [name, source] of Object.entries({
    app,
    signalsmith,
    pitchWorklet,
    rubberBandWorklet,
  })) {
    const modulePath = path.join(temporaryDirectory, `${name}.mjs`);
    await writeFile(modulePath, source);
    const syntaxCheck = spawnSync(process.execPath, ["--check", modulePath], {
      encoding: "utf8",
    });
    assert.equal(
      syntaxCheck.status,
      0,
      syntaxCheck.stderr || `${name} bundle did not parse`,
    );
  }

  const secondBuild = path.join(temporaryDirectory, "Harmonizer-Web-Offline.html");
  const result = spawnSync(
    process.execPath,
    [path.join(scriptDirectory, "build_single_file_web.mjs"), secondBuild],
    { encoding: "utf8" },
  );
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const rebuilt = await readFile(secondBuild);
  assert.deepEqual(rebuilt, await readFile(builtPath), "standalone build is not deterministic");
} finally {
  await rm(temporaryDirectory, { recursive: true, force: true });
}

console.log("single-file browser build tests passed");
