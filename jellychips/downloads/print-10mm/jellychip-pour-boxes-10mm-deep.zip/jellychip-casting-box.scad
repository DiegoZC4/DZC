// Jellychip silicone casting masters. Millimetres; print as oriented, open side up.
// One closed part per export. A CAD solid is *not* a demand for 100% slicer infill.
// The outlines below are the existing corner-marked, no-hole presets (nominal, zero kerf).
/* [Shape] */
shape = "square"; // [square, triangle]
square_side_mm = 5;
triangle_side_mm = 10;
/* [Food cavity] */
cavity_depth_mm = 10; // Carrying headroom. Not a gel thickness or fill line; weigh 10 g per 100-chip slab.
/* [Poured silicone and printed PETG] */
silicone_min_side_mm = 6;   // Minimum land from any boss corner to the wall's inner face.
silicone_back_mm = 4;       // Silicone over the boss when struck level to the box rim.
petg_floor_mm = 2;
petg_min_wall_mm = 2.4;
inner_wall_draft_deg = 2;   // Box opens outward. No draft or taper on chip-defining faces.
/* [Hidden] */
n = 144; // Circular wall flats designed by apothem. n divisible by 4.
eps = 0.02;
square = [[-6,-1],[-5,-1],[-5,-2],[-4,-2],[-4,-3],[-3,-3],[-3,-2],[-2,-2],[-2,-3],[-1,-3],[-1,-4],[-2,-4],[-2,-5],[-1,-5],[-1,-6],[0,-6],[0,-5],[1,-5],[1,-6],[2,-6],[2,-5],[3,-5],[3,-4],[4,-4],[4,-3],[5,-3],[5,-2],[6,-2],[6,-1],[7,-1],[7,0],[6,0],[6,1],[5,1],[5,2],[6,2],[6,3],[5,3],[5,4],[4,4],[4,5],[3,5],[3,6],[2,6],[2,7],[1,7],[1,6],[0,6],[0,7],[-1,7],[-1,6],[-2,6],[-2,5],[-3,5],[-3,4],[-4,4],[-4,3],[-5,3],[-5,2],[-6,2],[-6,1],[-5,1],[-5,0],[-6,0]];
triangle = [[-4,2],[-3,1],[-3,0],[-2,-1],[-1,-1],[-1,-2],[0,-2],[0,-3],[1,-3],[2,-4],[3,-4],[3,-3],[4,-4],[4,-3],[5,-3],[5,-2],[4,-1],[5,-1],[5,0],[4,1],[4,2],[3,3],[2,3],[1,4],[0,4],[0,5],[-1,5],[-1,4],[-2,5],[-3,5],[-3,4],[-4,4],[-3,3],[-4,3]];
is_sq = shape == "square";
side = is_sq ? square_side_mm : triangle_side_mm;
c = is_sq ? [0.5,0.5] : [1,sqrt(3)/3]; // center of enclosing circle, in side-length units
function xy(p) = is_sq ? p : [p[0]+p[1]/2,p[1]*sqrt(3)/2];
outline = [for (p=(is_sq?square:triangle)) side*(xy(p)-c)];
boss_h = cavity_depth_mm;
pour_h = boss_h+silicone_back_mm;
height = petg_floor_mm+pour_h;
radius = max([for (p=outline) norm(p)]);
inner_a = radius+silicone_min_side_mm;
top_a = inner_a+pour_h*tan(inner_wall_draft_deg);
function circum(a) = a/cos(180/n);

assert(shape=="square" || shape=="triangle");
assert(min(side,cavity_depth_mm,petg_floor_mm,petg_min_wall_mm,silicone_min_side_mm,silicone_back_mm)>0);
assert(inner_wall_draft_deg>=0 && inner_wall_draft_deg<=10 && petg_floor_mm>eps);
echo(shape=shape, cell_side_mm=side, food_cavity_depth_mm=boss_h,
     dimensions_mm=[2*circum(top_a+petg_min_wall_mm),2*circum(top_a+petg_min_wall_mm),height]);
union() {
    difference() {
        cylinder(h=height,r=circum(top_a+petg_min_wall_mm),$fn=n);
        // Cutter continues past rim at the same slope; there is no inward lip.
        translate([0,0,petg_floor_mm])
            cylinder(h=pour_h+eps,r1=circum(inner_a),r2=circum(top_a+eps*tan(inner_wall_draft_deg)),$fn=n);
    }
    // Deliberate overlap with base: no floating insert, coincident seam or through-hole.
    // The face on top of this boss becomes the floor of the silicone food cavity.
    translate([0,0,petg_floor_mm-eps])
        linear_extrude(height=boss_h+eps,convexity=30) polygon(outline);
}
