#!/usr/bin/env node

import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(scriptDirectory, "..");
const publicDirectory = path.join(root, "public");
const outputPath = process.argv[2]
  ? path.resolve(process.cwd(), process.argv[2])
  : path.join(root, "dist", "Harmonizer-Web-Offline.html");

async function readUtf8(filePath) {
  const bytes = await readFile(filePath);
  const text = bytes.toString("utf8");
  if (!Buffer.from(text, "utf8").equals(bytes)) {
    throw new Error(`${filePath} is not valid UTF-8`);
  }
  return text;
}

function replaceOnce(source, pattern, replacement, label) {
  const flags = [...new Set(`${pattern.flags}g`)].join("");
  const matches = source.match(new RegExp(pattern.source, flags)) || [];
  if (matches.length !== 1) {
    throw new Error(`Expected one ${label}, found ${matches.length}`);
  }
  return source.replace(pattern, () => replacement);
}

function stripNamedExports(source) {
  return source.replace(/^export\s+/gm, "");
}

function encode(source) {
  return Buffer.from(source, "utf8").toString("base64");
}

const [
  indexHtml,
  appSource,
  pitchSource,
  midiRollSource,
  pitchWorkletSource,
  rubberBandWorkletSource,
  signalsmithSource,
  rubberBandSource,
  faviconSource,
] = await Promise.all([
  readUtf8(path.join(publicDirectory, "index.html")),
  readUtf8(path.join(publicDirectory, "app.js")),
  readUtf8(path.join(publicDirectory, "pitch.js")),
  readUtf8(path.join(publicDirectory, "midi-roll.js")),
  readUtf8(path.join(publicDirectory, "pitch-worklet.js")),
  readUtf8(path.join(publicDirectory, "rubberband-worklet.js")),
  readUtf8(path.join(publicDirectory, "vendor", "SignalsmithStretch.js")),
  readUtf8(path.join(publicDirectory, "vendor", "RubberBandLive.js")),
  readFile(path.join(publicDirectory, "harmonizer.svg")),
]);

const appWithoutSignalsmithImport = replaceOnce(
  appSource,
  /^import\s+SignalsmithStretch\s+from\s+["'][^"']*SignalsmithStretch\.js[^"']*["'];\s*/m,
  "",
  "Signalsmith app import",
);
const appWithoutPitchImport = replaceOnce(
  appWithoutSignalsmithImport,
  /^import\s*\{[^}]*\}\s*from\s+["'][^"']*pitch\.js[^"']*["'];\s*/m,
  "",
  "pitch app import",
);
const appWithoutImports = replaceOnce(
  appWithoutPitchImport,
  /^import\s*\{[^}]*\}\s*from\s+["'][^"']*midi-roll\.js[^"']*["'];\s*/m,
  "",
  "MIDI roll app import",
);
const pitchCore = stripNamedExports(pitchSource);

const pitchWorkletWithoutImport = replaceOnce(
  pitchWorkletSource,
  /^import\s+\{\s*RealtimePitchTracker\s*\}\s+from\s+["'][^"']*pitch\.js[^"']*["'];\s*/m,
  "",
  "pitch worklet import",
);
const rubberBandWorkletWithoutImport = replaceOnce(
  rubberBandWorkletSource,
  /^import\s+createRubberBandLiveModule\s+from\s+["'][^"']*RubberBandLive\.js[^"']*["'];\s*/m,
  "",
  "Rubber Band worklet import",
);
const rubberBandWithoutExport = replaceOnce(
  rubberBandSource,
  /\bexport\s+default\s+createRubberBandLiveModule\s*;\s*$/m,
  "",
  "Rubber Band default export",
);

const bundles = {
  app: [
    // The vendor module also registers itself when loaded in AudioWorklet scope.
    'const { default: SignalsmithStretch } = await import(globalThis.__HARMONIZER_WORKLET_URLS__.signalsmith);',
    "// Shared pitch utilities",
    pitchCore,
    stripNamedExports(midiRollSource),
    "// Harmonizer application",
    appWithoutImports,
  ].join("\n"),
  pitchWorklet: [
    "// Shared pitch utilities",
    pitchCore,
    "// Pitch AudioWorklet",
    pitchWorkletWithoutImport,
  ].join("\n"),
  rubberBandWorklet: [
    "// Rubber Band Live WebAssembly",
    rubberBandWithoutExport,
    "// Rubber Band AudioWorklet",
    rubberBandWorkletWithoutImport,
  ].join("\n"),
};

for (const [name, source] of Object.entries(bundles)) {
  if (/(^|\n)\s*(import|export)\s/m.test(source)) {
    throw new Error(`${name} bundle still contains an ES module dependency`);
  }
}

const payloadJson = JSON.stringify({
  signalsmith: encode(signalsmithSource),
  app: encode(bundles.app),
  pitchWorklet: encode(bundles.pitchWorklet),
  rubberBandWorklet: encode(bundles.rubberBandWorklet),
});

const noticePaths = ["LICENSE", "public/vendor/LICENSE-rubberband.txt", "public/vendor/LICENSE-signalsmith-stretch.txt"];
const notices = await Promise.all(noticePaths.map(async file => file + "\n" + await readUtf8(path.join(root, file))));
const bootstrap = `  <script id="harmonizer-licenses" type="text/plain">${notices.join("\n\n").replace(/<\/script/gi, "<\\/script")}</script>
  <script id="harmonizer-standalone-payloads" type="application/json">${payloadJson}</script>
  <script>
    (() => {
      "use strict";
      const payloads = JSON.parse(
        document.getElementById("harmonizer-standalone-payloads").textContent,
      );
      // Chrome can fetch data modules in an AudioWorklet opened from a local HTML file.
      const moduleUrl = (encoded) => "data:text/javascript;base64," + encoded;
      globalThis.__HARMONIZER_WORKLET_URLS__ = Object.freeze({
        pitch: moduleUrl(payloads.pitchWorklet),
        rubberband: moduleUrl(payloads.rubberBandWorklet),
        signalsmith: moduleUrl(payloads.signalsmith),
      });

      import(moduleUrl(payloads.app)).catch((error) => {
        console.error("Harmonizer standalone startup failed", error);
        document.getElementById("engine-chip").textContent = "startup error";
        const status = document.getElementById("start-error");
        status.textContent = "Could not load the offline app. Reopen a fresh copy of this HTML file.";
        status.hidden = false;
        document.getElementById("start-overlay").hidden = false;
        document.getElementById("start-overlay-button").disabled = true;
      });
    })();
  </script>`;

const favicon = `data:image/svg+xml;base64,${faviconSource.toString("base64")}`;
let output = replaceOnce(
  indexHtml,
  /<link\s+rel="icon"\s+type="image\/svg\+xml"\s+href="\.\/harmonizer\.svg">/,
  `<link rel="icon" type="image/svg+xml" href="${favicon}">`,
  "favicon link",
);
output = replaceOnce(
  output,
  /href="\.\/downloads\/Harmonizer-Web-Offline\.html"/,
  'href="./Harmonizer-Web-Offline.html"',
  "offline download link",
);
output = replaceOnce(
  output,
  /\s*<script\s+type="module"\s+src="\.\/app\.js[^"]*"><\/script>/,
  `\n${bootstrap}`,
  "application module script",
);

await mkdir(path.dirname(outputPath), { recursive: true });
await writeFile(outputPath, output);

const outputBytes = Buffer.byteLength(output);
const digest = createHash("sha256").update(output).digest("hex");
console.log(`Built ${outputPath}`);
console.log(`${outputBytes} bytes, sha256 ${digest}`);
