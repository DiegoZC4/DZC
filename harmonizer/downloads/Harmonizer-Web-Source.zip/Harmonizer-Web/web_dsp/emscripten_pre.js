var performance = globalThis?.performance || {
  now: _ => Date.now()
};
