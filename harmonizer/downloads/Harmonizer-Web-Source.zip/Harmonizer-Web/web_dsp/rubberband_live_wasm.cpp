#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

#include <emscripten.h>
#include <rubberband/RubberBandLiveShifter.h>
#include "wide_voice_filter.hpp"

namespace {

constexpr int kMaxVoices = 4;
constexpr int kPitchWindow = 2048;
constexpr int kPitchHistory = 9;
constexpr int kCorrectionHistory = 16;
constexpr float kPi = 3.14159265358979323846f;

float clampf(float value, float minimum, float maximum) {
    return std::min(maximum, std::max(minimum, value));
}

float frequencyToMidi(float frequency) {
    return frequency > 0.0f
        ? 69.0f + 12.0f * std::log2(frequency / 440.0f)
        : -1.0f;
}

double realtimePitchRatio(float shift) {
    // Limit the phase-table size of Rubber Band's variable-ratio resampler.
    // Its I/O ratio is the reciprocal. Twelve significant binary bits cost
    // less than half a cent across the rehearsal range.
    const double inv=std::exp2(-double(shift)/12);
    int exponent;
    std::frexp(inv,&exponent);
    const double denominator=std::min(65536.0,std::ldexp(1.0,12-exponent));
    return denominator/std::max(1.0,std::round(inv*denominator));
}

struct DetectorResult {
    float frequency = -1.0f;
    float clarity = 0.0f;
};

class PitchTracker {
public:
    explicit PitchTracker(int sampleRate)
        : sampleRate_(sampleRate),
          analysisRate_(sampleRate * 0.5f),
          ring_(kPitchWindow, 0.0f),
          analysis_(kPitchWindow / 2, 0.0f),
          difference_(kPitchWindow / 4 + 1, 0.0f) {
        pitchHistory_.fill(-1.0f);
        correctionHistory_.fill(-1.0f);
    }

    void configure(float gate, float stability) {
        gate_ = std::max(0.0f, gate);
        stability_ = clampf(stability, 0.05f, 12.0f);
    }

    void pushBlock(const float* input, int frames, bool trackTargets) {
        float energy = 0.0f;
        float highEnergy = 0.0f;
        float low = lowpass_;
        int crossings = 0;
        int previousSign = previousHighSign_;
        const float lowpassCoefficient =
            1.0f - std::exp(-2.0f * kPi * 3000.0f / sampleRate_);

        for (int index = 0; index < frames; ++index) {
            const float sample = input[index];
            ring_[ringWrite_] = sample;
            ringWrite_ = (ringWrite_ + 1) % ring_.size();
            ringFill_ = std::min(ringFill_ + 1, ring_.size());
            sampleClock_++;
            energy += sample * sample;

            low += lowpassCoefficient * (sample - low);
            const float high = sample - low;
            highEnergy += high * high;
            const int sign = high > 0.0005f ? 1 : high < -0.0005f ? -1 : 0;
            if (sign != 0) {
                if (previousSign != 0 && sign != previousSign) crossings++;
                previousSign = sign;
            }
        }
        lowpass_ = low;
        previousHighSign_ = previousSign;

        rms_ = std::sqrt(energy / std::max(1, frames));
        const float highBandRatio = highEnergy / std::max(energy, 1.0e-12f);
        const float crossingsPer8ms =
            crossings * (0.008f * sampleRate_ / std::max(1, frames));
        sibilance_ = clampf(
            std::min(highBandRatio / 0.40f, crossingsPer8ms / 16.0f),
            0.0f, 4.0f);
        const bool sibilant =
            highBandRatio >= 0.40f && crossingsPer8ms >= 16.0f;
        previousHighSign_ = 0;

        const float detectorGate = gate_ * (voiced_ ? 0.55f : 1.0f);
        DetectorResult result;
        if (ringFill_ >= ring_.size() && rms_ >= detectorGate) {
            result = detectWindow();
        }
        clarity_ = result.clarity;
        float rawMidi = frequencyToMidi(result.frequency);
        if (sibilant && highBandRatio >= 0.65f) rawMidi = -1.0f;
        rawMidi_ = rawMidi;

        correctionHistory_[correctionWrite_] = rawMidi;
        correctionWrite_ = (correctionWrite_ + 1) % correctionHistory_.size();
        const int delayedIndex =
            (correctionWrite_ - 2 + correctionHistory_.size())
            % correctionHistory_.size();
        const float delayed = correctionHistory_[delayedIndex];
        if (rawMidi > 0.0f) {
            correctionMidi_ = delayed > 0.0f ? delayed : rawMidi;
        } else if (holdFrames_ <= 0) {
            correctionMidi_ = -1.0f;
        }

        pitchHistory_[pitchWrite_] = rawMidi;
        pitchWrite_ = (pitchWrite_ + 1) % pitchHistory_.size();
        int valid = 0;
        for (float midi : pitchHistory_) {
            if (midi > 0.0f) sortedPitch_[valid++] = midi;
        }
        for (int index = 1; index < valid; ++index) {
            const float value = sortedPitch_[index];
            int destination = index - 1;
            while (destination >= 0 && sortedPitch_[destination] > value) {
                sortedPitch_[destination + 1] = sortedPitch_[destination];
                destination--;
            }
            sortedPitch_[destination + 1] = value;
        }
        const float median = valid > 0 ? sortedPitch_[valid / 2] : -1.0f;
        int agree = 0;
        for (int index = 0; index < valid; ++index) {
            if (std::fabs(sortedPitch_[index] - median) < stability_) agree++;
        }

        const float releaseGate = gate_ * 0.55f;
        const bool stable =
            valid >= 3 && agree * 2 > valid && rms_ >= releaseGate;
        energetic_ = rms_ >= std::max(0.0005f, gate_ * 0.20f);
        if (stable) {
            if (detectedMidi_ < 0.0f ||
                std::fabs(median - detectedMidi_) > 1.5f) {
                detectedMidi_ = median;
            } else {
                detectedMidi_ +=
                    clampf(median - detectedMidi_, -2.0f, 2.0f) * 0.30f;
            }
            stable_ = true;
            voiced_ = true;
            holdFrames_ = 10;
        } else if (voiced_ && holdFrames_ > 0 && energetic_) {
            stable_ = false;
            holdFrames_--;
        } else {
            detectedMidi_ = -1.0f;
            stable_ = false;
            voiced_ = false;
            holdFrames_ = 0;
        }

        if (stable_ && correctionMidi_ > 0.0f && energetic_) {
            heldSourceMidi_ = correctionMidi_;
            heldSilenceSamples_ = 0;
        } else if (energetic_) {
            heldSilenceSamples_ = 0;
        } else if (heldSourceMidi_ > 0.0f) {
            heldSilenceSamples_ += frames;
            if (heldSilenceSamples_ >= static_cast<int>(sampleRate_ * 0.80f)) {
                heldSourceMidi_ = -1.0f;
                heldSilenceSamples_ = 0;
            }
        }

        unvoiced_ = energetic_ && heldSourceMidi_ > 0.0f &&
                    (sibilant || !stable_);
        if (unvoiced_) {
            voiced_ = true;
            correctionMidi_ = heldSourceMidi_;
        } else if (!voiced_ && !energetic_) {
            correctionMidi_ = -1.0f;
        }
        if (trackTargets) {
            trackingNow_ = rawMidi > 0.0f && !sibilant && result.clarity >= 0.72f;
            if (!energetic_) {
                contourSize_ = 0;
                jumpCandidate_ = -1.0f;
            }
            if (trackingNow_) trackRecentPeriod(result.frequency, frames);
        }
    }

    float sourceForTarget(float target, int block, int shifterDelay) const {
        if (!contourSize_) return correctionMidi_;
        if (!trackingNow_) return point(0).midi; // consonant: hold the last voiced interval
        // LiveShifter resamples the incoming block for upward shifts, but its
        // buffered output for downward shifts. One shared F0 time is wrong for
        // mixed chords. Offsets were measured on rendered short-window sweeps.
        const auto atAge = [&](float age) { return pitchAt(double(sampleClock_) - age, block); };
        const float recent = atAge(0.55f * block);
        const float ratio = std::exp2((target - recent) / 12.0f);
        if (target - recent >= 2.0f) return recent;
        const float age = 0.5f * block + 0.5f * shifterDelay * (1.0f + 1.0f / std::min(1.0f,ratio));
        const float up = std::max(0.0f, target-recent), down = std::min(0.0f, target-atAge(age));
        return target - (up + down);
    }

    float rawMidi() const { return rawMidi_; }
    float detectedMidi() const { return detectedMidi_; }
    float correctionMidi() const { return correctionMidi_; }
    float rms() const { return rms_; }
    float clarity() const { return clarity_; }
    float sibilance() const { return sibilance_; }
    bool stable() const { return stable_; }
    bool voiced() const { return voiced_; }
    bool energetic() const { return energetic_; }
    bool unvoiced() const { return unvoiced_; }
    uint64_t sampleClock() const { return sampleClock_; }

private:
    struct Point { double sample; float midi; };
    static constexpr int kContour = 32;
    const Point& point(int back) const {
        return contour_[(contourWrite_ - 1 - back + kContour) % kContour];
    }
    float pitchAt(double when, int block) const {
        const Point* next = &point(0);
        for (int i = 1; i < contourSize_; ++i) {
            const Point& prev = point(i);
            if (when >= prev.sample) {
                const double dt = next->sample - prev.sample;
                if (dt < 1 || dt > 2.5 * block || std::fabs(next->midi - prev.midi) > 1.5f)
                    return when - prev.sample < next->sample - when ? prev.midi : next->midi;
                const float u = clampf(float((when - next->sample) / dt), -1.0f, 1.0f);
                return next->midi + u * (next->midi - prev.midi);
            }
            next = &prev;
        }
        return next->midi;
    }
    void trackRecentPeriod(float frequency, int block) {
        // The full-window detector identifies the octave. Refit that period to
        // the last two cycles so that vibrato is not averaged over the whole window.
        const float expected = analysisRate_ / frequency;
        const int center = int(std::round(expected)), span = std::max(12, center);
        const int width = std::max(2, int(std::ceil(expected * 0.065f)));
        const int lo = std::max(2, center - width);
        const int hi = std::min(int(analysis_.size()) - span, center + width);
        const int start = int(analysis_.size()) - span;
        auto agreement = [&](int lag) {
            float dot = 0, energy = 0;
            for (int i = start; i < int(analysis_.size()); ++i) {
                const float a = analysis_[i], b = analysis_[i-lag];
                dot += a*b;
                energy += a*a + b*b;
            }
            return 2.0f * dot / std::max(energy, 1.e-12f);
        };
        int best = lo;
        float peak = -1;
        for (int lag = lo; lag <= hi; ++lag) {
            const float q = agreement(lag);
            if (q > peak) { best = lag; peak = q; }
        }
        Point p{double(sampleClock_) - 0.5 * ring_.size(), frequencyToMidi(frequency)};
        if (peak >= 0.76f && best > lo && best < hi) {
            const float l = agreement(best-1), r = agreement(best+1);
            const float d = l - 2.0f * peak + r;
            const float lag = best + (d < -1.e-9f ? clampf(0.5f*(l-r)/d, -.5f, .5f) : 0.0f);
            p.midi = frequencyToMidi(analysisRate_ / lag);
            p.sample = double(sampleClock_) - (span + lag) * 0.5 * (sampleRate_ / analysisRate_);
        }
        if (contourSize_) {
            const Point& last = point(0);
            if (p.sample <= last.sample) return;
            // A lone octave error is not a new sung note. Accept a real leap
            // on its second agreeing estimate; never interpolate across it.
            if (p.sample-last.sample < 3*block && std::fabs(p.midi-last.midi)>7.0f &&
                (jumpCandidate_ < 0 || std::fabs(jumpCandidate_-p.midi)>1.5f)) {
                jumpCandidate_=p.midi;
                trackingNow_=false;
                return;
            }
        }
        jumpCandidate_=-1;
        contour_[contourWrite_] = p;
        contourWrite_ = (contourWrite_ + 1) % kContour;
        contourSize_ = std::min(contourSize_+1, kContour);
    }

    DetectorResult detectWindow() {
        for (size_t index = 0; index < analysis_.size(); ++index) {
            const size_t first =
                (ringWrite_ + index * 2) % ring_.size();
            const size_t second = (first + 1) % ring_.size();
            analysis_[index] = 0.5f * (ring_[first] + ring_[second]);
        }

        constexpr float kMinimumHz = 51.9f;
        constexpr float kMaximumHz = 1046.6f;
        const int maxTau = std::min(
            static_cast<int>(difference_.size()) - 1,
            static_cast<int>(analysisRate_ / kMinimumHz));
        const int minTau = std::max(2, static_cast<int>(analysisRate_ / kMaximumHz));
        for (int tau = 1; tau <= maxTau; ++tau) {
            float sum = 0.0f;
            const int limit = static_cast<int>(analysis_.size()) - tau;
            for (int index = 0; index < limit; ++index) {
                const float delta = analysis_[index] - analysis_[index + tau];
                sum += delta * delta;
            }
            difference_[tau] = sum;
        }

        float running = 0.0f;
        difference_[0] = 1.0f;
        for (int tau = 1; tau <= maxTau; ++tau) {
            running += difference_[tau];
            difference_[tau] =
                running > 0.0f ? difference_[tau] * tau / running : 1.0f;
        }

        int tau = -1;
        for (int candidate = minTau; candidate < maxTau; ++candidate) {
            if (difference_[candidate] < 0.13f) {
                tau = candidate;
                while (tau + 1 <= maxTau &&
                       difference_[tau + 1] < difference_[tau]) {
                    tau++;
                }
                break;
            }
        }
        if (tau < 0) {
            int best = minTau;
            for (int candidate = minTau + 1; candidate <= maxTau; ++candidate) {
                if (difference_[candidate] < difference_[best]) best = candidate;
            }
            if (difference_[best] > 0.28f) return {};
            tau = best;
        }

        const float left = difference_[std::max(1, tau - 1)];
        const float center = difference_[tau];
        const float right = difference_[std::min(maxTau, tau + 1)];
        const float denominator = left - 2.0f * center + right;
        const float refined = std::fabs(denominator) > 1.0e-12f
            ? tau + 0.5f * (left - right) / denominator
            : static_cast<float>(tau);
        const float frequency = analysisRate_ / refined;
        if (!std::isfinite(frequency) ||
            frequency < kMinimumHz || frequency > kMaximumHz) {
            return {};
        }
        return {frequency, clampf(1.0f - center, 0.0f, 1.0f)};
    }

    int sampleRate_;
    float analysisRate_;
    float gate_ = 0.01f;
    float stability_ = 1.0f;
    std::vector<float> ring_;
    std::vector<float> analysis_;
    std::vector<float> difference_;
    std::array<float, kPitchHistory> pitchHistory_;
    std::array<float, kPitchHistory> sortedPitch_{};
    std::array<float, kCorrectionHistory> correctionHistory_;
    std::array<Point, kContour> contour_{};
    int contourWrite_ = 0, contourSize_ = 0;
    float jumpCandidate_ = -1;
    bool trackingNow_ = false;
    size_t ringWrite_ = 0;
    size_t ringFill_ = 0;
    int pitchWrite_ = 0;
    int correctionWrite_ = 0;
    int holdFrames_ = 0;
    int heldSilenceSamples_ = 0;
    int previousHighSign_ = 0;
    uint64_t sampleClock_ = 0;
    float lowpass_ = 0.0f;
    float rawMidi_ = -1.0f;
    float detectedMidi_ = -1.0f;
    float correctionMidi_ = -1.0f;
    float heldSourceMidi_ = -1.0f;
    float rms_ = 0.0f;
    float clarity_ = 0.0f;
    float sibilance_ = 0.0f;
    bool stable_ = false;
    bool voiced_ = false;
    bool energetic_ = false;
    bool unvoiced_ = false;
};

struct Voice {
    explicit Voice(int sampleRate)
        : shifter(
              sampleRate,
              1,
              RubberBand::RubberBandLiveShifter::OptionFormantPreserved |
                  RubberBand::RubberBandLiveShifter::OptionWindowShort), wideFilter(sampleRate) {
        shifter.setPitchScale(1.0);
    }

    RubberBand::RubberBandLiveShifter shifter;
    WideVoiceFilter wideFilter;
    std::vector<float> output;
    int note = -1;
    bool gate = false;
    float velocity = 1.0f;
    float envelope = 0.0f;
    double pitchRatio = 1.0;
    bool formantsPreserved = true;
};

class HarmonizerEngine {
public:
    HarmonizerEngine(int sampleRate, int quantumSize)
        : sampleRate_(sampleRate),
          quantumSize_(quantumSize),
          pitch_(sampleRate) {
        for (auto& voice : voices_) {
            voice = std::make_unique<Voice>(sampleRate_);
        }
        blockSize_ = static_cast<int>(voices_[0]->shifter.getBlockSize());
        startDelay_ = static_cast<int>(voices_[0]->shifter.getStartDelay());
        capture_.assign(blockSize_, 0.0f);
        pendingInput_.assign(blockSize_, 0.0f);
        pendingMixLeft_.assign(blockSize_, 0.0f);
        pendingMixRight_.assign(blockSize_, 0.0f);
        readyLeft_.assign(blockSize_, 0.0f);
        readyRight_.assign(blockSize_, 0.0f);
        const float* warmupInput[] = {capture_.data()};
        for (auto& voice : voices_) {
            voice->output.assign(blockSize_, 0.0f);
            float* warmupOutput[] = {voice->output.data()};
            voice->shifter.shift(warmupInput, warmupOutput);
            voice->shifter.reset();
            voice->shifter.setPitchScale(1.0);
        }
        attackCoefficient_ =
            1.0f - std::exp(-1.0f / (0.005f * sampleRate_));
        releaseCoefficient_ =
            1.0f - std::exp(-1.0f / (0.080f * sampleRate_));
    }

    void configure(float gate, float stability, float pitchBend, bool formants) {
        pitch_.configure(gate, stability);
        pitchBend_ = clampf(pitchBend, -2.0f, 2.0f);
        preserveFormants_ = formants;
    }

    void configureAutocorrect(
        float strength,
        int pitchClassMask,
        float toleranceCents) {
        autoCorrectionEnabled_ = (pitchClassMask & 0x0fff) != 0;
        autoCorrectionStrength_ = clampf(strength, 0.0f, 1.0f);
        autoPitchClassMask_ = pitchClassMask & 0x0fff;
        autoToleranceSemitones_ = clampf(toleranceCents / 100.0f, 0.0f, 1.0f);
    }

    void setVoice(int index, int note, bool gate, float velocity) {
        if (index < 0 || index >= kMaxVoices) return;
        Voice& voice = *voices_[index];
        if (voice.note != note) voice.wideFilter.reset();
        if (note > 0 && voice.note <= 0) {
            voice.shifter.reset();
            voice.pitchRatio = 1.0f;
            voice.envelope = 0.0f;
        }
        voice.note = note;
        voice.gate = gate;
        voice.velocity = clampf(velocity, 0.0f, 1.0f);
        if (note <= 0) {
            voice.gate = false;
            voice.envelope = 0.0f;
        }
    }

    void process(const float* input, float* outputLeft, float* outputRight, int frames) {
        std::fill(outputLeft, outputLeft + frames, 0.0f);
        std::fill(outputRight, outputRight + frames, 0.0f);

        processPendingVoice();
        if (readyAvailable_) {
            const int available = blockSize_ - readyRead_;
            const int copyCount = std::min(frames, available);
            std::copy_n(readyLeft_.data() + readyRead_, copyCount, outputLeft);
            std::copy_n(readyRight_.data() + readyRead_, copyCount, outputRight);
            readyRead_ += copyCount;
            if (readyRead_ >= blockSize_) {
                readyRead_ = 0;
                readyAvailable_ = false;
            }
        }

        int source = 0;
        while (source < frames) {
            const int count =
                std::min(frames - source, blockSize_ - captureWrite_);
            std::copy_n(input + source, count, capture_.data() + captureWrite_);
            source += count;
            captureWrite_ += count;
            if (captureWrite_ >= blockSize_) {
                if (!pendingAvailable_) beginPendingBlock();
                captureWrite_ = 0;
            }
        }
    }

    int blockSize() const { return blockSize_; }
    int startDelay() const { return startDelay_; }

    int latencySamples() const {
        const int schedulingDelay = autoCorrectionEnabled_
            ? 0
            : std::max(0, kMaxVoices - 1) * quantumSize_;
        return blockSize_ + startDelay_ + schedulingDelay;
    }

    int activeVoices() const {
        if (autoCorrectionEnabled_) return 1;
        int active = 0;
        for (const auto& voice : voices_) {
            if (voice->note > 0 && (voice->gate || voice->envelope > 0.001f)) {
                active++;
            }
        }
        return active;
    }

    float telemetry(int index) const {
        switch (index) {
        case 0: return pitch_.rawMidi();
        case 1: return pitch_.detectedMidi();
        case 2: return pitch_.correctionMidi();
        case 3: return pitch_.rms();
        case 4: return pitch_.clarity();
        case 5: return pitch_.stable() ? 1.0f : 0.0f;
        case 6: return pitch_.voiced() ? 1.0f : 0.0f;
        case 7: return pitch_.energetic() ? 1.0f : 0.0f;
        case 8: return pitch_.unvoiced() ? 1.0f : 0.0f;
        case 9: return pitch_.sibilance();
        case 10: return static_cast<float>(activeVoices());
        case 11: return autoTargetMidi_;
        case 12: return autoAppliedSemitones_;
        case 13: return autoCorrectionStrength_;
        default: return 0.0f;
        }
    }

    uint64_t sampleClock() const { return pitch_.sampleClock(); }

private:
    bool voiceAudible(const Voice& voice) const {
        return voice.note > 0 && (voice.gate || voice.envelope > 0.001f);
    }

    float nearestAllowedMidi(float sourceMidi) const {
        if (sourceMidi <= 0.0f || autoPitchClassMask_ == 0) return -1.0f;
        const int center = static_cast<int>(std::round(sourceMidi));
        float nearest = -1.0f;
        float nearestDistance = 1000.0f;
        for (int note = center - 12; note <= center + 12; ++note) {
            const int pitchClass = ((note % 12) + 12) % 12;
            if ((autoPitchClassMask_ & (1 << pitchClass)) == 0) continue;
            const float distance = std::fabs(note - sourceMidi);
            if (distance < nearestDistance) {
                nearest = static_cast<float>(note);
                nearestDistance = distance;
            }
        }
        return nearest;
    }

    void beginPendingBlock() {
        pendingInput_.swap(capture_);
        std::fill(pendingMixLeft_.begin(), pendingMixLeft_.end(), 0.0f);
        std::fill(pendingMixRight_.begin(), pendingMixRight_.end(), 0.0f);
        pitch_.pushBlock(pendingInput_.data(), blockSize_, !autoCorrectionEnabled_);
        pendingSourceMidi_ = pitch_.correctionMidi();
        pendingVoiced_ = pitch_.voiced() && pendingSourceMidi_ > 0.0f;
        pendingActiveVoices_ = activeVoices();
        pendingVoice_ = 0;
        pendingAvailable_ = true;
    }

    void processPendingVoice() {
        if (!pendingAvailable_) return;
        if (autoCorrectionEnabled_) {
            processPendingAutocorrect();
            return;
        }
        Voice& voice = *voices_[pendingVoice_];
        const bool audible = voiceAudible(voice);
        if (audible) {
            if (voice.formantsPreserved != preserveFormants_) {
                voice.shifter.setFormantOption(
                    preserveFormants_
                        ? RubberBand::RubberBandLiveShifter::OptionFormantPreserved
                        : RubberBand::RubberBandLiveShifter::OptionFormantShifted);
                voice.formantsPreserved = preserveFormants_;
            }
            const float targetMidi = voice.note + pitchBend_;
            float shift = 0;
            if (pendingVoiced_) {
                shift = targetMidi - pitch_.sourceForTarget(targetMidi, blockSize_, startDelay_);
                voice.pitchRatio = realtimePitchRatio(shift);
            }
            voice.shifter.setPitchScale(voice.pitchRatio);
            const float* inputChannels[] = {pendingInput_.data()};
            float* outputChannels[] = {voice.output.data()};
            voice.shifter.shift(inputChannels, outputChannels);
            voice.wideFilter.process(voice.output.data(), blockSize_, targetMidi, shift,
                                     pendingVoiced_ && !pitch_.unvoiced());

            const float spread = clampf((voice.note - 48.0f) / 24.0f, 0.0f, 1.0f);
            const float side = voice.note % 2 == 0 ? -1.0f : 1.0f;
            const float theta = (side * spread + 1.0f) * 0.25f * kPi;
            const float panLeft = std::cos(theta);
            const float panRight = std::sin(theta);
            const float voiceLevel = pendingActiveVoices_ > 0
                ? 1.0f / std::sqrt(static_cast<float>(pendingActiveVoices_))
                : 0.0f;
            for (int sample = 0; sample < blockSize_; ++sample) {
                const float target = voice.gate ? voice.velocity : 0.0f;
                const float coefficient =
                    target > voice.envelope ? attackCoefficient_ : releaseCoefficient_;
                voice.envelope += (target - voice.envelope) * coefficient;
                if (voice.envelope < 0.0001f) voice.envelope = 0.0f;
                const float shifted = pendingVoiced_
                    ? voice.output[sample] * voice.envelope * voiceLevel
                    : 0.0f;
                pendingMixLeft_[sample] += shifted * panLeft;
                pendingMixRight_[sample] += shifted * panRight;
            }
        }

        pendingVoice_++;
        if (pendingVoice_ < kMaxVoices) return;
        for (int sample = 0; sample < blockSize_; ++sample) {
            pendingMixLeft_[sample] = std::tanh(pendingMixLeft_[sample]);
            pendingMixRight_[sample] = std::tanh(pendingMixRight_[sample]);
        }
        readyLeft_.swap(pendingMixLeft_);
        readyRight_.swap(pendingMixRight_);
        readyRead_ = 0;
        readyAvailable_ = true;
        pendingAvailable_ = false;
    }

    void processPendingAutocorrect() {
        Voice& voice = *voices_[0];
        if (voice.formantsPreserved != preserveFormants_) {
            voice.shifter.setFormantOption(
                preserveFormants_
                    ? RubberBand::RubberBandLiveShifter::OptionFormantPreserved
                    : RubberBand::RubberBandLiveShifter::OptionFormantShifted);
            voice.formantsPreserved = preserveFormants_;
        }

        autoTargetMidi_ = nearestAllowedMidi(pendingSourceMidi_);
        autoAppliedSemitones_ = 0.0f;
        if (autoTargetMidi_ > 0.0f && pendingSourceMidi_ > 0.0f) {
            const float error = autoTargetMidi_ - pendingSourceMidi_;
            const float magnitude = std::max(
                0.0f,
                std::fabs(error) - autoToleranceSemitones_);
            autoAppliedSemitones_ = std::copysign(
                magnitude * autoCorrectionStrength_,
                error);
        }
        voice.pitchRatio = std::pow(2.0f, autoAppliedSemitones_ / 12.0f);
        voice.shifter.setPitchScale(voice.pitchRatio);

        const float* inputChannels[] = {pendingInput_.data()};
        float* outputChannels[] = {voice.output.data()};
        voice.shifter.shift(inputChannels, outputChannels);
        for (int sample = 0; sample < blockSize_; ++sample) {
            const float shifted = clampf(voice.output[sample], -1.0f, 1.0f);
            pendingMixLeft_[sample] = shifted;
            pendingMixRight_[sample] = shifted;
        }

        readyLeft_.swap(pendingMixLeft_);
        readyRight_.swap(pendingMixRight_);
        readyRead_ = 0;
        readyAvailable_ = true;
        pendingAvailable_ = false;
    }

    int sampleRate_;
    int quantumSize_;
    int blockSize_ = 0;
    int startDelay_ = 0;
    int captureWrite_ = 0;
    int pendingVoice_ = 0;
    int pendingActiveVoices_ = 0;
    int readyRead_ = 0;
    float pitchBend_ = 0.0f;
    float attackCoefficient_ = 0.0f;
    float releaseCoefficient_ = 0.0f;
    float pendingSourceMidi_ = -1.0f;
    float autoCorrectionStrength_ = 0.0f;
    float autoToleranceSemitones_ = 0.0f;
    float autoTargetMidi_ = -1.0f;
    float autoAppliedSemitones_ = 0.0f;
    int autoPitchClassMask_ = 0;
    bool preserveFormants_ = true;
    bool autoCorrectionEnabled_ = false;
    bool pendingVoiced_ = false;
    bool pendingAvailable_ = false;
    bool readyAvailable_ = false;
    PitchTracker pitch_;
    std::array<std::unique_ptr<Voice>, kMaxVoices> voices_;
    std::vector<float> capture_;
    std::vector<float> pendingInput_;
    std::vector<float> pendingMixLeft_;
    std::vector<float> pendingMixRight_;
    std::vector<float> readyLeft_;
    std::vector<float> readyRight_;
};

std::unique_ptr<HarmonizerEngine> gEngine;
std::vector<float> gIo;
int gQuantumSize = 128;
double gLastProcessMs = 0.0;

}  // namespace

extern "C" {

EMSCRIPTEN_KEEPALIVE
int rb_init(int sampleRate, int quantumSize) {
    gQuantumSize = std::max(1, quantumSize);
    gEngine = std::make_unique<HarmonizerEngine>(sampleRate, gQuantumSize);
    gIo.assign(gQuantumSize * 3, 0.0f);
    return 1;
}

EMSCRIPTEN_KEEPALIVE
void rb_destroy() {
    gEngine.reset();
    gIo.clear();
}

EMSCRIPTEN_KEEPALIVE
float* rb_input_ptr() {
    return gIo.data();
}

EMSCRIPTEN_KEEPALIVE
float* rb_output_left_ptr() {
    return gIo.data() + gQuantumSize;
}

EMSCRIPTEN_KEEPALIVE
float* rb_output_right_ptr() {
    return gIo.data() + gQuantumSize * 2;
}

EMSCRIPTEN_KEEPALIVE
void rb_configure(float gate, float stability, float pitchBend, int formants) {
    if (gEngine) {
        gEngine->configure(gate, stability, pitchBend, formants != 0);
    }
}

EMSCRIPTEN_KEEPALIVE
void rb_configure_autocorrect(
    float strength,
    int pitchClassMask,
    float toleranceCents) {
    if (gEngine) {
        gEngine->configureAutocorrect(
            strength,
            pitchClassMask,
            toleranceCents);
    }
}

EMSCRIPTEN_KEEPALIVE
void rb_set_voice(int index, int note, int gate, float velocity) {
    if (gEngine) gEngine->setVoice(index, note, gate != 0, velocity);
}

EMSCRIPTEN_KEEPALIVE
void rb_process(int frames) {
    if (!gEngine || frames != gQuantumSize) return;
    const double startedAt = emscripten_get_now();
    gEngine->process(
        gIo.data(),
        gIo.data() + gQuantumSize,
        gIo.data() + gQuantumSize * 2,
        frames);
    gLastProcessMs = emscripten_get_now() - startedAt;
}

EMSCRIPTEN_KEEPALIVE
int rb_block_size() {
    return gEngine ? gEngine->blockSize() : 0;
}

EMSCRIPTEN_KEEPALIVE
int rb_start_delay() {
    return gEngine ? gEngine->startDelay() : 0;
}

EMSCRIPTEN_KEEPALIVE
int rb_latency_samples() {
    return gEngine ? gEngine->latencySamples() : 0;
}

EMSCRIPTEN_KEEPALIVE
float rb_telemetry(int index) {
    return gEngine ? gEngine->telemetry(index) : 0.0f;
}

EMSCRIPTEN_KEEPALIVE
double rb_sample_clock() {
    return gEngine ? static_cast<double>(gEngine->sampleClock()) : 0.0;
}

EMSCRIPTEN_KEEPALIVE
double rb_process_ms() {
    return gLastProcessMs;
}

}

int main() {
    return 0;
}
