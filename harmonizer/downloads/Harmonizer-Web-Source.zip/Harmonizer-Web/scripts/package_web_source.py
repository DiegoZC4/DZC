"""Package only the standalone web release's sources and pinned build inputs."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ".deps/rubberband-v4.0.0.tar.gz"
FILES = (
    "LICENSE", "THIRD_PARTY_NOTICES.md", "WEB-SOURCE.md",
    "public/index.html", "public/app.js", "public/pitch.js", "public/midi-roll.js",
    "public/pitch-worklet.js", "public/rubberband-worklet.js", "public/harmonizer.svg",
    "public/vendor/RubberBandLive.js", "public/vendor/SignalsmithStretch.js",
    "public/vendor/LICENSE-rubberband.txt", "public/vendor/LICENSE-signalsmith-stretch.txt",
    "web_dsp/rubberband_live_wasm.cpp", "web_dsp/wide_voice_filter.hpp", "web_dsp/emscripten_pre.js",
    "scripts/fetch_rubberband.sh", "scripts/build_web_wasm.sh", "scripts/build_single_file_web.mjs",
    "scripts/package_web_source.py", "scripts/test_single_file_web.mjs", ARCHIVE,
)


def main():
    dependency = ROOT / ARCHIVE
    if not dependency.is_file() or sha256(dependency.read_bytes()).hexdigest() != (
        "24300f48a8014b7c863b573a9647e61b1b19b37875e2cdd92005e64c6424d266"
    ):
        raise SystemExit("The pinned Rubber Band 4.0.0 source archive is missing or does not match.")
    output = ROOT / "dist/Harmonizer-Web-Source.zip"
    output.parent.mkdir(exist_ok=True)
    with ZipFile(output, "w") as archive:
        for name in FILES:
            entry = ZipInfo("Harmonizer-Web/" + name)
            entry.create_system = 3
            entry.external_attr = (0o100755 if name.endswith(".sh") else 0o100644) << 16
            archive.writestr(entry, (ROOT / name).read_bytes(), compress_type=ZIP_DEFLATED)
    print(f"Built {output.name} ({output.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
