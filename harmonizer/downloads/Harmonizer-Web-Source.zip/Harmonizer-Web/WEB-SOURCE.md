# Harmonizer browser edition

This archive corresponds to the browser instrument at
<https://diegozc.com/harmonizer/>. It includes the application, AudioWorklets,
prebuilt WebAssembly modules, the custom C++ DSP, the pinned Rubber Band
4.0.0 source archive, licenses, and build scripts. It contains no recordings.

To rebuild the single offline HTML from the supplied modules, run in this directory:

```sh
node scripts/build_single_file_web.mjs
node scripts/test_single_file_web.mjs
```

The result is `dist/Harmonizer-Web-Offline.html`. Browser users do not need
Node or a compiler. For a modular deployment, serve the contents of `public/`
over HTTPS and place the offline HTML and source ZIP in its `downloads/` folder.

To modify and recompile the Rubber Band module, install Emscripten with
`em++` on your path and use a POSIX shell (or WSL on Windows):

```sh
tar -xzf .deps/rubberband-v4.0.0.tar.gz -C .deps
bash scripts/build_web_wasm.sh
node scripts/build_single_file_web.mjs
python3 scripts/package_web_source.py
```
