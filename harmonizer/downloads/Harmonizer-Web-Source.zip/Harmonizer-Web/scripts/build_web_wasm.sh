#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
rubberband_source="$("$root/scripts/fetch_rubberband.sh")"
output="$root/public/vendor/RubberBandLive.js"
export EM_CACHE="${EM_CACHE:-$root/.deps/emscripten-cache}"

command -v em++ >/dev/null 2>&1 || {
  echo "Emscripten is required. Install it with: brew install emscripten" >&2
  exit 1
}

mkdir -p "$(dirname "$output")"
mkdir -p "$EM_CACHE"

em++ \
  "$root/web_dsp/rubberband_live_wasm.cpp" \
  "$rubberband_source/single/RubberBandSingle.cpp" \
  -I"$rubberband_source" \
  -o "$output" \
  --pre-js "$root/web_dsp/emscripten_pre.js" \
  -std=c++17 -O3 -flto -DNDEBUG -ffast-math -fno-rtti -fwasm-exceptions -msimd128 \
  -Wall -Wextra \
  -sEXPORT_NAME=createRubberBandLiveModule \
  -sMODULARIZE=1 -sEXPORT_ES6=1 \
  -sENVIRONMENT=web,worker \
  -sSINGLE_FILE=1 -sFILESYSTEM=0 \
  -sMALLOC=emmalloc \
  -sINITIAL_MEMORY=64MB -sALLOW_MEMORY_GROWTH=1 \
  -sNO_EXIT_RUNTIME=1 -sINVOKE_RUN=0 \
  -sASSERTIONS=0 -sDYNAMIC_EXECUTION=0 \
  -sEXPORTED_RUNTIME_METHODS=HEAPF32

echo "Built ${output#$root/}"
